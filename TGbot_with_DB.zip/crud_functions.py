import sqlite3


def initiate_db():
    connection = sqlite3.connect("tg.db")
    cursor = connection.cursor()
    cursor.execute('''
CREATE TABLE IF NOT EXISTS Products(
id INT PRIMARY KEY,
title TEXT NOT NULL,
description TEXT,
price INT NOT NULL
)
''')
    connection.commit()
    connection.close()

# Заполним таблицу
# Вообще-то это будут делать через какой-то интерфейс или даже напрямую через менеджер баз
# но чтобы не вводить руками... товаров может быть 100500
try:
    initiate_db()
    connection = sqlite3.connect("tg.db")
    cursor = connection.cursor()
    for i in range(5):
        cursor.execute('INSERT INTO Products(id, title, description, price) VALUES (?,?,?,?)',
                       (i+1, f'Продукт{i + 1}', f'Пояснение{i + 1}', (i + 1) * 100))
except sqlite3.IntegrityError as E:
    print('Похоже, в таблице уже есть поля с такими id')
finally:
    connection.commit()
    connection.close()

# вернем массив продуктов из базы
def get_all_products():

    products = []
    connection = sqlite3.connect("tg.db")
    cursor = connection.cursor()
    cursor.execute('SELECT * FROM Products')
    all_products = cursor.fetchall()
    for product in all_products:
        # products.append({f'id:{product[0]}', f'Название:  {product[1]}',f'Описание: {product[2]}',f'Цена: {product[3]}'})
        # Думаю id тут не нужно выводить. У нас и так есть индекс массива
        products.append((product[1],product[2],product[3]))

    connection.commit()
    connection.close()
    return products

# отладочные дела
# prod = get_all_products()
# print(prod)


