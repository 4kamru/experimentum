import sqlite3


def initiate_db():
    connection = sqlite3.connect("tg.db")
    cursor = connection.cursor()
    # создаем таблицу товаров
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS Products(
    id INT PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT,
    price INT NOT NULL
    )
    ''')
    connection.commit()
    # создаем таблицу пользователей
    # в первичном ключе автоинкремент и уникальность, чтобы не думать при добавлении записей
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS Users(
    id INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE,
    username TEXT NOT NULL,
    email TEXT NOT NULL,
    age INTEGER NOT NULL,
    balance INTEGER NOT NULL
    )
    ''')
    connection.commit()
    connection.close()

# добавляем пользователя
# может быть придется раскомментировать первые 2 строки, если ругнется, что курсор не определен
def add_user(username, email, age):
    connection = sqlite3.connect("tg.db")
    cursor = connection.cursor()
    cursor.execute(f'''
            INSERT INTO Users(username,email,age,balance) VALUES('{str(username)}', '{str(email)}', '{int(age)}', 1000)
    ''')
    connection.commit()
    connection.close()

# проверка, есть ли такой пользователь
# ИМХО: маловато проверки по username , хотел еще email поставить, но в ТЗ не задали это
def is_included(username):
    connection = sqlite3.connect("tg.db")
    cursor = connection.cursor()
    check_user = cursor.execute('SELECT * FROM Users WHERE username=?', (username, ))
    # connection.commit() #### возможно тут будет ошибка - рано коммит поставил
    if check_user.fetchone() is None:
        connection.commit()
        connection.close()
        return False
    else:
        connection.commit()
        connection.close()
        return True


# Заполним таблицу
# Вообще-то это будут делать через какой-то интерфейс или даже напрямую через менеджер баз
# но чтобы не вводить руками... товаров может быть 100500

initiate_db()
connection = sqlite3.connect("tg.db")
cursor = connection.cursor()
try:
    for i in range(5):
        cursor.execute('INSERT INTO Products(id, title, description, price) VALUES (?,?,?,?)',
                       (i+1, f'Продукт{i + 1}', f'Пояснение{i + 1}', (i + 1) * 100))

except sqlite3.IntegrityError as E:
    print('Похоже, в таблице уже есть поля с такими id')

connection.commit()
connection.close()

# вернем массив продуктов из базы
def get_all_products():

    products = []
    connection = sqlite3.connect("tg.db")
    cursor = connection.cursor()
    cursor.execute('SELECT * FROM Products')
    all_products = cursor.fetchall()
    for product in all_products:
        # products.append({f'id:{product[0]}', f'Название:  {product[1]}',f'Описание: {product[2]}',f'Цена: {product[3]}'})
        # Думаю id тут не нужно выводить. У нас и так есть индекс массива
        products.append((product[1],product[2],product[3]))

    connection.commit()
    connection.close()
    return products

# отладочные дела
# prod = get_all_products()
# print(prod)


